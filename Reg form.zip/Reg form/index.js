function validateForm() {
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;
    let mobile = document.getElementById("mobile").value;

    let isValid = true;

    document.getElementById("nameError").innerHTML = "";
    document.getElementById("emailError").innerHTML = "";
    document.getElementById("passwordError").innerHTML = "";
    document.getElementById("mobileError").innerHTML = "";
    if (name === "") {
        document.getElementById("nameError").innerHTML = "Name is required";
        isValid = false;
    }
    let emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    if (email === "") {
        document.getElementById("emailError").innerHTML = "Email is required";
        isValid = false;
    } else if (!email.match(emailPattern)) {
        document.getElementById("emailError").innerHTML = "Invalid email format";
        isValid = false;
    }
    if (password === "") {
        document.getElementById("passwordError").innerHTML = "Password is required";
        isValid = false;
    } else if (password.length < 6) {
        document.getElementById("passwordError").innerHTML = "Minimum 6 characters required";
        isValid = false;
    }
    if (mobile === "") {
        document.getElementById("mobileError").innerHTML = "Mobile number is required";
        isValid = false;
    } else if (!/^[0-9]{10}$/.test(mobile)) {
        document.getElementById("mobileError").innerHTML =
            "Mobile number must be exactly 10 digits";
        isValid = false;
    }

    if (isValid) {
        document.getElementById("successModal").style.display = "block";
        document.getElementById("myForm").reset();
    }

    return false; 
}

function closeModal() {
    document.getElementById("successModal").style.display = "none";
}